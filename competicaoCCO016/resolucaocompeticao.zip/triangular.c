#include<stdio.h>

int main(){
    int num, triangular = 0, i = 1;
    printf("Digite um numero: ");
    scanf("%d", &num);
    while(i <= num){
        triangular = triangular + i;
        i = i + 1;
    }
    if(triangular == num){
        printf("Triangular\n");
    }else{
        printf("Nao triangular\n");
    }
    
    return 0;
}