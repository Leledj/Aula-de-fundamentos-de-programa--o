#include<stdio.h>

int main(){
    int num, primos = 0, i = 2;
    printf("Digite um numero: ");
    scanf("%d", &num);
    while(i < num){
        if(num % i == 0){
            primos = primos + 1;
        }
        i = i + 1;
        if(primos != 1){
            printf("%d\n", primos);
        }

    }
  

    return 0;
}